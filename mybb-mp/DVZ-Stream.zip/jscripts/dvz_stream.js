var dvz_stream = {

    // settings
    interval: 5,
    limit: 6,
    lazyMode: false,
    lazyMargin: 0,
    groupEventsBy: [],

    // runtime
    streamPointers: [],
    activeStreams: [],
    started: false,
    frozen: false,

    loop: function ()
    {
        if (!dvz_stream.lazyLoad()) {
            dvz_stream.frozen = true;
            return false;
        }

        // initialize stream information
        if (!dvz_stream.started) {
            dvz_stream.started = true;
        }

        dvz_stream.update(function(){
            // next request
            if (dvz_stream.interval) {
                setTimeout(dvz_stream.loop, dvz_stream.interval * 1000);
            }
        });
    },

    // actions
    update: function (callback)
    {
        if (dvz_stream.activeStreams.length) {

            var activeStreamPointers = {};

            for (var i in dvz_stream.activeStreams) {
                var id = dvz_stream.activeStreams[i];
                activeStreamPointers[id] = dvz_stream.streamPointers[id];
            }

            $.get(
                'xmlhttp.php',
                { action: 'dvz_stream_get', streams: activeStreamPointers, limit: dvz_stream.limit },
                function(data) {

                    if (data) {
                        var response = $.parseJSON(data);

                        if (response.hasOwnProperty('html')) {
                            var $newHtml = $(response.html);

                            $newHtml.filter('.event').each(function () {
                                // mark new items
                                $(this).addClass('new');

                                // remove old grouped items
                                var groupName = $(this).attr('data-event-group-name');

                                if (groupName && dvz_stream.groupEventsBy.includes(groupName)) {
                                    var groupId = $(this).attr('data-event-group-id');

                                    $('#dvz_stream .event[data-event-group-id="' + groupId + '"]').remove();
                                }
                            });

                            $('#dvz_stream .data').prepend($newHtml);

                            // remove old items to fit the limit
                            var old = $('#dvz_stream .event').length - dvz_stream.limit;
                            if (old > 0) {
                                $('#dvz_stream .event:nth-last-child(-n+' + old + ')').remove();
                            }

                            setTimeout("$('#dvz_stream .event.new').removeClass('new')", 1000);
                        }

                        if (response.hasOwnProperty('streams')) {
                            for (var streamName in response.streams) {
                                if (response.streams[streamName]) {
                                    dvz_stream.streamPointers[streamName] = response.streams[streamName];
                                }
                            }
                        }
                    }

                    if (typeof(callback) == 'function') {
                        callback();
                    }

                }
            );

        } else {
            if (typeof(callback) == 'function') {
                callback();
            }
        }
    },

    setStreamStatus: function (streamName, status)
    {
        if (status == true) {
            dvz_stream.activeStreams.push(streamName);
            $('#dvz_stream [data-stream-name='+streamName+']').addClass('active');
        } else {
            dvz_stream.activeStreams.splice(dvz_stream.activeStreams.indexOf(streamName), 1);
            $('#dvz_stream [data-stream-name='+streamName+']').removeClass('active');
        }
    },

    // lazyLoad handling
    lazyLoad: function ()
    {
        if (dvz_stream.lazyMode && !dvz_stream.onDisplay()) {
            if (
                dvz_stream.lazyMode == 'start' && !dvz_stream.started ||
                dvz_stream.lazyMode == 'always'
            ) {
                return false;
            }
        }
        return true;
    },

    onDisplay: function ()
    {
        var viewTop = $(document).scrollTop(),
            viewBottom = viewTop + $(window).height(),
            elementTop = $('#dvz_stream').offset().top,
            elementBottom = elementTop + $('#dvz_stream').height();

        return elementBottom >= (viewTop - dvz_stream.lazyMargin) && elementTop <= (viewBottom + dvz_stream.lazyMargin);
    },

    checkVisibility: function ()
    {
        if (dvz_stream.frozen && dvz_stream.onDisplay()) {
            dvz_stream.frozen = false;
            dvz_stream.loop();
        }
    },
};

$(function(){
    $(window).bind('scroll resize', dvz_stream.checkVisibility);
    $(document).on('change', '#dvz_stream input', function() {
        dvz_stream.setStreamStatus( $(this).parent().attr('data-stream-name'), $(this).prop('checked') );
        return false;
    });

    setTimeout(dvz_stream.loop, dvz_stream.interval * 1000);
});

dvz_stream.interval = document.currentScript.dataset['interval'];
dvz_stream.limit = document.currentScript.dataset['limit'];
dvz_stream.lazyMode = document.currentScript.dataset['lazyMode'];
dvz_stream.groupEventsBy = document.currentScript.dataset['groupEventsBy'].split(',');
dvz_stream.streamPointers = $.parseJSON(document.currentScript.dataset['streamPointers']);
dvz_stream.activeStreams = Object.keys(dvz_stream.streamPointers);
