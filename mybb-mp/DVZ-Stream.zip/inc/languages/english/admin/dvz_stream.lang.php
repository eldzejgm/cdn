<?php

$l['dvz_stream_description'] = 'Real-time stream of new content appearing on the forum.';

$l['dvz_stream_admin_pluginlibrary_missing'] = 'Add <a href="https://mods.mybb.com/view/pluginlibrary">PluginLibrary</a> in order to use the plugin.';

$l['setting_group_dvz_stream'] = 'DVZ Stream';
$l['setting_group_dvz_stream_desc'] = 'Settings for DVZ Stream.';

$l['setting_dvz_stream_active_streams'] = 'Active streams';
$l['setting_dvz_stream_active_streams_desc'] = 'Comma-separated names of streams to be displayed.';

$l['setting_dvz_stream_group_events_by'] = 'Event grouping';
$l['setting_dvz_stream_group_events_by_desc'] = 'Comma-separated names of event groups for which only the most recent entry should be displayed.';

$l['setting_dvz_stream_widget_enabled'] = 'Index page widget';
$l['setting_dvz_stream_widget_enabled_desc'] = 'Enable a <code>{$dvz_stream}</code> widget that can be inserted to forum index templates.';

$l['setting_dvz_stream_limit_widget'] = 'Number of entries in the Stream widget';
$l['setting_dvz_stream_limit_widget_desc'] = '';

$l['setting_dvz_stream_interval_widget'] = 'Refresh interval: Stream widget (seconds)';
$l['setting_dvz_stream_interval_widget_desc'] = 'Interval between AJAX Stream update requests (lower values provide better synchronization but cause higher server load). Set 0 to disable the auto-refreshing feature.';

$l['setting_dvz_stream_limit_page'] = 'Number of entries on the Stream page';
$l['setting_dvz_stream_limit_page_desc'] = '';

$l['setting_dvz_stream_interval_page'] = 'Refresh interval: Stream page (seconds)';
$l['setting_dvz_stream_interval_page_desc'] = '';

$l['setting_dvz_stream_lazyload'] = 'Lazy load';
$l['setting_dvz_stream_lazyload_desc'] = 'Start loading data only when the Stream is actually being displayed on the screen (the page is scrolled to the Stream position).';
$l['setting_dvz_stream_lazyload_off'] = 'Disabled';
$l['setting_dvz_stream_lazyload_start'] = 'Check if on display to start';
$l['setting_dvz_stream_lazyload_always'] = 'Always check if on display to refresh';

$l['setting_dvz_stream_groups_view'] = 'Group permissions: View';
$l['setting_dvz_stream_groups_view_desc'] = '';

$l['setting_dvz_stream_groups_update'] = 'Group permissions: Auto-update';
$l['setting_dvz_stream_groups_update_desc'] = '';

$l['setting_dvz_stream_hidden_forums'] = 'Hidden forums';
$l['setting_dvz_stream_hidden_forums_desc'] = 'Select which forums should be omitted by streams.';
