<?php

$l['dvz_stream_title'] = 'Stream';
$l['dvz_stream_page_link'] = 'see more';
$l['dvz_stream_select'] = 'Select new content streams';

// default streams
$l['dvz_stream_stream_posts'] = 'Replies';
$l['dvz_stream_stream_posts_event'] = 'New reply';
$l['dvz_stream_stream_posts_label_replies'] = 'Replies';

$l['dvz_stream_stream_threads'] = 'Threads';
$l['dvz_stream_stream_threads_event'] = 'New thread';

$l['dvz_stream_stream_users'] = 'Users';
$l['dvz_stream_stream_users_event'] = 'New user';
