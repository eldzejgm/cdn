<?php

namespace dvzStream;

class StreamEvent
{
    public $id;
    public $groupName;
    public $groupId;
    public $stream;
    public $date;
    public $location;
    public $item;
    public $user = [];
    public $labels = [];
    public $data = [];

    public function setId(int $id)
    {
        $this->id = $id;
    }

    public function getId(): int
    {
        return $this->id;
    }

    public function setGroupName(string $groupName)
    {
        $this->groupName = $groupName;
    }

    public function getGroupName()
    {
        return $this->groupName;
    }

    public function setGroupId(int $groupId)
    {
        $this->groupId = $groupId;
    }

    public function getGroupId()
    {
        return $this->groupId;
    }

    public function setStream(Stream $stream)
    {
        $this->stream = $stream;
    }

    public function getStream(): Stream
    {
        return $this->stream;
    }

    public function setDate(int $date)
    {
        $this->date = $date;
    }

    public function getDate(): int
    {
        return $this->date;
    }

    public function setLocation(string $location)
    {
        $this->location = $location;
    }

    public function getLocation()
    {
        return $this->location;
    }

    public function setItem(string $item)
    {
        $this->item = $item;
    }

    public function getItem()
    {
        return $this->item;
    }

    public function setUser(array $user)
    {
        $this->user = $user;
    }

    public function getUser(): array
    {
        return $this->user;
    }

    public function setLabels(array $labels)
    {
        $this->labels = $labels;
    }

    public function getLabels(): array
    {
        return $this->labels;
    }

    public function addData(array $data)
    {
        $this->data = array_merge($this->data, $data);
    }

    public function getData(): array
    {
        return $this->data;
    }
}
