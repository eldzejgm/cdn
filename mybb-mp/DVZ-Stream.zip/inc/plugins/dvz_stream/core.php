<?php

namespace dvzStream;

function defaultFormatHandler(StreamEvent $streamEvent): string
{
    global $mybb, $lang;

    $event = [];

    $user = $streamEvent->getUser();

    $event['id'] = $streamEvent->getId();
    $event['group_name'] = $streamEvent->getGroupName();
    $event['group_id'] = $streamEvent->getGroupId();
    $event['stream_name'] = \htmlspecialchars_uni($streamEvent->getStream()->getName());
    $event['title'] = $streamEvent->getStream()->getEventTitle();
    $event['date'] = \my_date($mybb->settings['dateformat'], $streamEvent->getDate(), null, true) . ', ' . \my_date($mybb->settings['timeformat'], $streamEvent->getDate(), null, true);
    $event['user_associated'] = $user ? 1 : 0;
    $event['user'] = $user
        ? \build_profile_link(
            \format_name(\htmlspecialchars_uni($user['username']), $user['usergroup'], $user['displaygroup']),
            $user['id']
        )
        : null;
    $event['user_avatar_url'] = \format_avatar($user['avatar'])['image'];
    $event['location'] = $streamEvent->getLocation()
        ? $streamEvent->getLocation()
        : null;
    $event['item'] = $streamEvent->getItem()
        ? $streamEvent->getItem()
        : null;

    if ($event['user_avatar_url']) {
        eval('$event[\'user_avatar\'] = "' . tpl('event_user_avatar') . '";');
    } else {
        $event['user_avatar'] = null;
    }

    $event['labels'] = null;

    foreach ($streamEvent->getLabels() as $labelName => $label) {
        $label['title'] = $label['title']
            ?? $lang->{'dvz_stream_stream_' . $streamEvent->getStream()->getName() . '_label_' . $labelName}
            ?? null;

        eval('$event[\'labels\'] .= "' . tpl('event_label') . '";');
    }

    $eventDetails = null;
    $eventAppendix = null;

    foreach ($streamEvent->getStream()->getPostFormatHandlers() as $handler) {
        $handler($streamEvent, $event, $eventDetails, $eventAppendix);
    }

    $templateName = $streamEvent->getStream()->getCustomTemplateName() ?? 'event';

    eval('$html = "' . tpl($templateName) . '";');

    return $html;
}

function getFormattedEvents(array $streamEvents)
{
    $html = null;

    foreach ($streamEvents as $streamEvent) {
        foreach ($streamEvent->getStream()->getProcessHandlers() as $handler) {
            $handler($streamEvent);
        }

        if ($handler = $streamEvent->getStream()->getCustomFormatHandler()) {
            $html .= $handler();
        } else {
            $html .= defaultFormatHandler($streamEvent);
        }

        foreach ($streamEvent->getStream()->getPostProcessHandlers() as $handler) {
            $handler($streamEvent);
        }
    }

    return $html;
}

function javascript(string $location, array $streamPointers)
{
    global $mybb;

    $html = null;

    if ($streamPointers) {
        $limit = (int)getSettingValue('limit_' . $location);

        $attributes = [
            'interval' => canUpdate() ? (float)getSettingValue('interval_' . $location) : 0,
            'limit' => (int)$limit,
            'lazy-mode' => in_array(getSettingValue('lazyload'), ['off', 'start', 'always']) ? getSettingValue('lazyload') : 'off',
            'group-events-by' => \htmlspecialchars_uni(getSettingValue('group_events_by')),
            'stream-pointers' => \htmlspecialchars_uni(json_encode($streamPointers))
        ];

        $attributesString = null;

        foreach ($attributes as $name => $value) {
            $attributesString .= ' data-' . $name . '="' . $value . '"';
        }

        $html .= '<script src="' . $mybb->asset_url . '/jscripts/dvz_stream.js" async defer' . $attributesString . '></script>' . PHP_EOL;
    }

    return $html;
}

// stream handling
function addStream(Stream $stream)
{
    global $dvzStreamStreams;

    $dvzStreamStreams[ $stream->getName() ] = $stream;
}

function loadActiveStreams()
{
    $streamNames = getActiveStreamNames();

    foreach ($streamNames as $streamName) {
        include_once MYBB_ROOT . 'inc/plugins/dvz_stream/streams/' . pathinfo($streamName, PATHINFO_FILENAME) . '.php';
    }
}

function getStreamEventsWithPointers(array $streamEventIdPointers = null, int $limit = null): array
{
    global $dvzStreamStreams;

    $streamEvents = [];

    loadActiveStreams();

    // get all streams
    if ($streamEventIdPointers === null) {
        $streamEventIdPointers = array_fill_keys(array_keys($dvzStreamStreams), 0);
    }

    foreach ($streamEventIdPointers as $streamName => $lastEventId) {

        if (isset($dvzStreamStreams[$streamName])) {

            $localStreamEvents = fetchStreamEvents($streamName, $limit, $lastEventId);

            if ($localStreamEvents) {
                $streamEventIdPointers[$streamName] = $localStreamEvents[0]->getId();
            }

            $streamEvents = array_merge($streamEvents, $localStreamEvents);
        }

    }

    // sort descending
    usort($streamEvents, function ($a, $b) {
        $dateDelta = $b->getDate() - $a->getDate();

        if ($dateDelta !== 0) {
            return $dateDelta;
        } elseif ($a->getStream() !== $b->getStream()) {
            return strcmp($a->getStream()->getName(), $b->getStream()->getName());
        } else {
            return $b->getId() - $a->getId();
        }
    });

    // limit items by 1 per group
    $groupEventsBy = getCsvSettingValues('group_events_by');

    if ($groupEventsBy) {
        $includedGroupIds = [];

        foreach ($streamEvents as $key => $streamEvent) {
            $groupName = $streamEvent->getGroupName();

            if ($groupName !== null && in_array($groupName, $groupEventsBy)) {
                $groupId = $streamEvent->getGroupId();

                if (in_array($groupId, $includedGroupIds[$groupName] ?? [])) {
                    unset($streamEvents[$key]);
                } else {
                    $includedGroupIds[$groupName][] = $groupId;
                }
            }
        }
    }

    // limit items
    $streamEvents = array_slice($streamEvents, 0, $limit);

    return [
        'streamEventIdPointers' => $streamEventIdPointers ?? [],
        'streamEvents' => $streamEvents,
    ];
}

function fetchStreamEvents(string $streamName, int $limit, int $lastEventId = null): array
{
    global $dvzStreamStreams;

    $streamEvents = $dvzStreamStreams[$streamName]->getFetchHandler()($limit, $lastEventId);

    return $streamEvents;
}

function getActiveStreamCustomTemplateNames(): array
{
    global $dvzStreamStreams;

    $entries = [];

    loadActiveStreams();

    foreach ($dvzStreamStreams as $stream) {
        $entries[] = $stream->getCustomTemplateName();
    }

    $entries = array_unique(array_filter($entries));

    return $entries;
}

function getActiveStreamNames(): array
{
    return getCsvSettingValues('active_streams');
}

// permissions
function canView(): bool
{
    $array = getCsvSettingValues('groups_view');

    return (isset($array[0]) && $array[0] == -1) || \is_member($array);
}

function canUpdate(): bool
{
    $array = getCsvSettingValues('groups_update');

    return (isset($array[0]) && $array[0] == -1) || \is_member($array);
}

function getInaccessibleForumIds(): array
{
    return array_filter(
        explode(',', \get_unviewable_forums(true) . ',' . \get_inactive_forums())
    );
}

function getOwnThreadsVisibleOnlyForumIds(): array
{
    $ids = [];

    $group_permissions = \forum_permissions();

    foreach ($group_permissions as $gpfid => $forum_permissions) {
        if (isset($forum_permissions['canonlyviewownthreads']) && $forum_permissions['canonlyviewownthreads'] == 1) {
            $ids[] = $gpfid;
        }
    }

    return $ids;
}

// common
function getSettingValue(string $name): string
{
    global $mybb;
    return $mybb->settings['dvz_stream_' . $name] ?? null;
}

function getCsvSettingValues(string $name): array
{
    global $mybb;

    return array_filter(explode(',', getSettingValue($name)));
}

function loadTemplates(array $templates, string $prefix = null)
{
    global $templatelist;

    if (!empty($templatelist)) {
        $templatelist .= ',';
    }
    if ($prefix) {
        $templates = preg_filter('/^/', $prefix, $templates);
    }

    $templatelist .= implode(',', $templates);
}

function tpl(string $name)
{
    global $templates;

    if (DEVELOPMENT_MODE) {
        return str_replace(
            "\\'",
            "'",
            addslashes(
                file_get_contents(MYBB_ROOT . 'inc/plugins/dvz_stream/templates/' . $name . '.tpl')
            )
        );
    } else {
        return $templates->get('dvzstream_' . $name);
    }
}
