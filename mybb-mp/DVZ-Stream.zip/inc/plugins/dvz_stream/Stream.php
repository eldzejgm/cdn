<?php

namespace dvzStream;

class Stream
{
    public $name;
    public $fetchHandler;
    public $processHandlers = [];
    public $postProcessHandlers = [];
    public $postFormatHandlers = [];
    public $customFormatHandler;
    public $title;
    public $eventTitle;
    public $customTemplateName = null;

    public function setName(string $name)
    {
        $this->name = $name;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function setFetchHandler(callable $handler)
    {
        $this->fetchHandler = $handler;
    }

    public function getFetchHandler(): callable
    {
        return $this->fetchHandler;
    }

    public function setCustomFormatHandler(callable $handler)
    {
        $this->customFormatHandler = $handler;
    }

    public function getCustomFormatHandler()
    {
        return $this->customFormatHandler;
    }

    public function addProcessHandler(callable $handler)
    {
        $this->processHandlers[] = $handler;
    }

    public function getProcessHandlers(): array
    {
        return $this->processHandlers;
    }

    public function addPostFormatHandler(callable $handler)
    {
        $this->postFormatHandlers[] = $handler;
    }

    public function getPostFormatHandlers(): array
    {
        return $this->postFormatHandlers;
    }

    public function addPostProcessHandler(callable $handler)
    {
        $this->postProcessHandlers[] = $handler;
    }

    public function getPostProcessHandlers(): array
    {
        return $this->postProcessHandlers;
    }

    public function setTitle(string $title)
    {
        $this->title = $title;
    }

    public function getTitle(): string
    {
        return $this->title;
    }

    public function setEventTitle(string $title)
    {
        $this->eventTitle = $title;
    }

    public function getEventTitle(): string
    {
        return $this->eventTitle;
    }

    public function setCustomTemplateName(string $name)
    {
        $this->customTemplateName = $name;
    }

    public function getCustomTemplateName()
    {
        return $this->customTemplateName;
    }
}
