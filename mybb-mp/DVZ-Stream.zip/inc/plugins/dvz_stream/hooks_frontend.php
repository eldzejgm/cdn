<?php

namespace dvzStream;

function global_start()
{
    global $mybb, $lang;

    if (
        (
            (THIS_SCRIPT == 'index.php' && getSettingValue('widget_enabled')) ||
            THIS_SCRIPT == 'misc.php' && $mybb->get_input('action') == 'stream'
        ) &&
        canView()
    ) {
        $lang->load('dvz_stream');

        loadTemplates([
            'event',
            'event_label',
            'event_user_avatar'
        ], 'dvzstream_');

        if (THIS_SCRIPT == 'misc.php') {
            loadTemplates([
                'label',
                'page',
            ], 'dvzstream_');
        } else {
            loadTemplates([
                'widget',
            ], 'dvzstream_');
        }

        loadTemplates(getActiveStreamCustomTemplateNames(), 'dvzstream_');
    }
}

function misc_start()
{
    global $mybb, $dvzStreamStreams, $lang, $theme, $footer, $headerinclude, $header, $charset;

    if ($mybb->get_input('action') == 'stream') {
        if (!canView('page')) {
            return;
        }

        header('Content-type: text/html; charset=' . $charset);

        \add_breadcrumb($lang->dvz_stream_title, 'misc.php?action=stream');

        $data = getStreamEventsWithPointers(null, getSettingValue('limit_page'));

        $html = getFormattedEvents($data['streamEvents']);

        if ((float)getSettingValue('interval_widget') > 0 && canUpdate()) {
            $javascript = javascript('page', $data['streamEventIdPointers']);
        } else {
            $javascript = null;
        }

        $streams = null;

        foreach ($dvzStreamStreams as $streamName => $stream) {
            $streamName = \htmlspecialchars_uni($stream->getName());
            $streamTitle = $stream->getTitle();

            eval('$streams .= "' . tpl('label') . '";');
        }

        eval('$content = "' . tpl('page') . '";');

        \output_page($content);

        exit;
    }
}

function xmlhttp()
{
    global $mybb, $lang, $charset;

    if ($mybb->get_input('action') == 'dvz_stream_get' && canUpdate()) {

        $lang->load('dvz_stream');

        $request = $mybb->get_input('streams', \MyBB::INPUT_ARRAY);

        $hardLimit = max(getSettingValue('limit_widget'), getSettingValue('limit_page'));
        $limit = isset($mybb->input['limit'])
            ? min($mybb->get_input('limit', \MyBB::INPUT_INT), $hardLimit)
            : $hardLimit;

        $data = getStreamEventsWithPointers($request, $limit);

        if ($data['streamEventIdPointers'] === $request) {
            $data = [];
        } else {
            $html = getFormattedEvents($data['streamEvents']);

            $data = [
                'streams' => $data['streamEventIdPointers'],
                'html' => $html,
            ];
        }

        header('Content-type: text/plain; charset=' . $charset);
        header('Cache-Control: no-store');

        echo json_encode($data);
    }
}

function index_end()
{
    global $dvz_stream, $lang, $mybb, $theme;

    $dvz_stream = null;

    if (getSettingValue('widget_enabled') && canView()) {
        $data = getStreamEventsWithPointers(null, getSettingValue('limit_widget'));

        $html = getFormattedEvents($data['streamEvents']);

        $streamPageUrl = $mybb->settings['bburl'] . '/misc.php?action=stream';

        if ((float)getSettingValue('interval_widget') > 0 && canUpdate()) {
            $javascript = javascript('widget', $data['streamEventIdPointers']);
        } else {
            $javascript = null;
        }

        eval('$dvz_stream = "' . tpl('widget') . '";');
    }
}
