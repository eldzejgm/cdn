<?php

namespace dvzStream;

function admin_config_settings_start()
{
    global $lang;

    $lang->load('dvz_stream');
}
