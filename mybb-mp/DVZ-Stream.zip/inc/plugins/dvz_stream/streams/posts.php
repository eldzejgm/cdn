<?php

global $lang;

$stream = new \dvzStream\Stream;

$stream->setName(explode('.', basename(__FILE__))[0]);

$stream->setTitle($lang->dvz_stream_stream_posts);
$stream->setEventTitle($lang->dvz_stream_stream_posts_event);

$stream->setFetchHandler(function (int $limit, int $lastEventId = 0) use ($stream) {
    global $mybb, $db, $cache;

    $streamEvents = [];

    $queryWhere = null;

    $hiddenForums = array_merge(
        \dvzStream\getInaccessibleForumIds(),
        \dvzStream\getCsvSettingValues('hidden_forums')
    );

    if (in_array(-1, $hiddenForums)) {
        return [];
    }

    $queryWhere = 'p.replyto != 0 AND t.visible = 1 AND p.visible = 1';

    if ($lastEventId != 0) {
        $queryWhere .= ' AND p.pid > ' . (int)$lastEventId;
    }

    if ($hiddenForums) {
        $queryWhere .= ' AND p.fid NOT IN (' . implode(',', $hiddenForums) . ')';
    }

    $ownThreadsVisiblyOnlyForumIds = \dvzStream\getOwnThreadsVisibleOnlyForumIds();

    if ($ownThreadsVisiblyOnlyForumIds) {
        $queryWhere .= ' AND (t.fid NOT IN (' . implode(',', $ownThreadsVisiblyOnlyForumIds) . ') OR t.uid = ' . (int)$mybb->user['uid'] . ')';
    }

    if (in_array('thread', \dvzStream\getCsvSettingValues('group_events_by'))) {
        $data = $db->query("
            SELECT
                p.pid, p.dateline,
                t.tid, t.subject, t.fid, t.prefix, t.replies,
                u.uid, u.username, u.usergroup, u.displaygroup, u.avatar
            FROM
                " . TABLE_PREFIX . "threads t
                INNER JOIN " . TABLE_PREFIX . "posts p ON p.tid = t.tid
                LEFT JOIN " . TABLE_PREFIX . "posts p2 ON p2.tid = t.tid AND p2.pid > p.pid
                LEFT JOIN " . TABLE_PREFIX . "users u  ON t.lastposteruid = u.uid
            WHERE
                " . $queryWhere . " AND p2.pid IS NULL
            ORDER BY p.pid DESC
            LIMIT " . (int)$limit . "
        ");
    } else {
        $data = $db->query("
            SELECT
                p.pid, p.dateline,
                t.tid, t.subject, t.fid, t.prefix, t.replies,
                u.uid, u.username, u.usergroup, u.displaygroup, u.avatar
            FROM
                " . TABLE_PREFIX . "posts p
                INNER JOIN " . TABLE_PREFIX . "threads t ON p.tid = t.tid
                LEFT JOIN " . TABLE_PREFIX . "users u ON p.uid = u.uid
            WHERE
                " . $queryWhere . "
            ORDER BY p.pid DESC
            LIMIT " . (int)$limit . "
        ");
    }

    $forums = $cache->read('forums');
    $prefixes = $cache->read('threadprefixes');

    while ($row = $db->fetch_array($data)) {
        $streamEvent = new \dvzStream\StreamEvent;

        $streamEvent->setStream($stream);
        $streamEvent->setId($row['pid']);
        $streamEvent->setGroupName('thread');
        $streamEvent->setGroupId($row['tid']);
        $streamEvent->setDate($row['dateline']);
        $streamEvent->setUser([
            'id' => $row['uid'],
            'username' => $row['username'],
            'usergroup' => $row['usergroup'],
            'displaygroup' => $row['displaygroup'],
            'avatar' => $row['avatar'],
        ]);
        $streamEvent->addData([
            'fid' => $row['fid'],
            'name' => $forums[ $row['fid'] ]['name'],
            'prefix' => $prefixes[ $row['prefix'] ] ?? null,
            'tid' => $row['tid'],
            'subject' => $row['subject'],
            'replies' => $row['replies'],
            'pid' => $row['pid'],
        ]);

        $streamEvents[] = $streamEvent;
    }

    return $streamEvents;
});

$stream->addProcessHandler(function (\dvzStream\StreamEvent $streamEvent) {
    global $mybb, $lang;

    $data = $streamEvent->getData();

    $locationUrl = $mybb->settings['bburl'] . '/' . \get_forum_link($data['fid']);
    $locationTitle = $data['name'];

    $location = '<a href="' . $locationUrl . '">' . $locationTitle . '</a>';

    $itemPrefix = isset($data['prefix']['displaystyle']) ? $data['prefix']['displaystyle'] . ' ' : null;
    $itemUrl = \get_post_link($data['pid'], $data['tid']) . '#pid' . (int)$data['pid'];
    $itemTitle = \htmlspecialchars_uni($data['subject']);

    $item = $itemPrefix . '<a href="' . $itemUrl . '" title="' . $itemTitle . '">' . $itemTitle . '</a>';

    $streamEvent->setLocation($location);
    $streamEvent->setItem($item);
    $streamEvent->setLabels([
        'replies' => [
            'value' => $data['replies'],
        ],
    ]);
});

\dvzStream\addStream($stream);
