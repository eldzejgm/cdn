<?php

global $lang;

$stream = new \dvzStream\Stream;

$stream->setName(explode('.', basename(__FILE__))[0]);

$stream->setTitle($lang->dvz_stream_stream_users);
$stream->setEventTitle($lang->dvz_stream_stream_users_event);

$stream->setFetchHandler(function (int $limit, int $lastEventId = 0) use ($stream) {
    global $db;

    $streamEvents = [];

    $data = $db->query("
        SELECT
            u.uid, u.regdate, u.username, u.usergroup, u.displaygroup, u.avatar
        FROM
            " . TABLE_PREFIX . "users u
        WHERE u.uid > " . (int)$lastEventId . " AND u.invisible = 0
        ORDER BY u.uid DESC
        LIMIT " . (int)$limit . "
    ");

    while ($row = $db->fetch_array($data)) {
        $streamEvent = new \dvzStream\StreamEvent;

        $streamEvent->setStream($stream);
        $streamEvent->setId($row['uid']);
        $streamEvent->setDate($row['regdate']);
        $streamEvent->setUser([
            'id' => $row['uid'],
            'username' => $row['username'],
            'usergroup' => $row['usergroup'],
            'displaygroup' => $row['displaygroup'],
            'avatar' => $row['avatar'],
        ]);

        $streamEvents[] = $streamEvent;
    }

    return $streamEvents;
});

\dvzStream\addStream($stream);
