<?php

global $lang;

$stream = new \dvzStream\Stream;

$stream->setName(explode('.', basename(__FILE__))[0]);

$stream->setTitle($lang->dvz_stream_stream_threads);
$stream->setEventTitle($lang->dvz_stream_stream_threads_event);

$stream->setFetchHandler(function (int $limit, int $lastEventId = 0) use ($stream) {
    global $mybb, $db, $cache;

    $streamEvents = [];

    $queryWhere = null;

    $hiddenForums = array_merge(
        \dvzStream\getInaccessibleForumIds(),
        \dvzStream\getCsvSettingValues('hidden_forums')
    );

    if (in_array(-1, $hiddenForums)) {
        return [];
    }

    if ($hiddenForums) {
        $queryWhere = 'AND t.fid NOT IN (' . implode(',', $hiddenForums) . ')';
    }

    $ownThreadsVisiblyOnlyForumIds = \dvzStream\getOwnThreadsVisibleOnlyForumIds();

    if ($ownThreadsVisiblyOnlyForumIds) {
        $queryWhere .= 'AND (t.fid NOT IN (' . implode(',', $ownThreadsVisiblyOnlyForumIds) . ') OR t.uid = ' . (int)$mybb->user['uid'] . ')';
    }

    $data = $db->query("
        SELECT
            t.tid, t.subject, t.fid, t.dateline, t.prefix,
            u.uid, u.username, u.usergroup, u.displaygroup, u.avatar
        FROM
            " . TABLE_PREFIX . "threads t
            LEFT JOIN " . TABLE_PREFIX . "users u ON t.uid = u.uid
        WHERE
            t.tid > " . (int)$lastEventId . " AND t.visible = 1 AND t.firstpost != 0 " . $queryWhere . "
        ORDER BY t.tid DESC
        LIMIT " . (int)$limit . "
    ");

    $forums = $cache->read('forums');
    $prefixes = $cache->read('threadprefixes');

    while ($row = $db->fetch_array($data)) {
        $streamEvent = new \dvzStream\StreamEvent;

        $streamEvent->setStream($stream);
        $streamEvent->setId($row['tid']);
        $streamEvent->setGroupName('thread');
        $streamEvent->setGroupId($row['tid']);
        $streamEvent->setDate($row['dateline']);
        $streamEvent->setUser([
            'id' => $row['uid'],
            'username' => $row['username'],
            'usergroup' => $row['usergroup'],
            'displaygroup' => $row['displaygroup'],
            'avatar' => $row['avatar'],
        ]);
        $streamEvent->addData([
            'fid' => $row['fid'],
            'name' => $forums[ $row['fid'] ]['name'],
            'prefix' => $prefixes[ $row['prefix'] ] ?? null,
            'tid' => $row['tid'],
            'subject' => $row['subject'],
        ]);

        $streamEvents[] = $streamEvent;
    }

    return $streamEvents;
});

$stream->addProcessHandler(function (\dvzStream\StreamEvent $streamEvent) {
    global $mybb;

    $data = $streamEvent->getData();

    $locationUrl = $mybb->settings['bburl'] . '/' . \get_forum_link($data['fid']);
    $locationTitle = $data['name'];

    $location = '<a href="' . $locationUrl . '">' . $locationTitle . '</a>';

    $itemPrefix = isset($data['prefix']['displaystyle']) ? $data['prefix']['displaystyle'] . ' ' : null;
    $itemUrl = \get_thread_link($data['tid']);
    $itemTitle = \htmlspecialchars_uni($data['subject']);

    $item =  $itemPrefix . '<a href="' . $itemUrl . '" title="' . $itemTitle . '">' . $itemTitle . '</a>';

    $streamEvent->setLocation($location);
    $streamEvent->setItem($item);
});

\dvzStream\addStream($stream);
