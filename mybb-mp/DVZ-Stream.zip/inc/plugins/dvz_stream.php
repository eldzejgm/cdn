<?php
/**
 * Copyright (c) 2017-2021, Tomasz 'Devilshakerz' Mlynski [devilshakerz.com]
 *
 * Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby
 * granted, provided that the above copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
 * INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN
 * AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */

// common modules
require MYBB_ROOT . 'inc/plugins/dvz_stream/core.php';
require MYBB_ROOT . 'inc/plugins/dvz_stream/Stream.php';
require MYBB_ROOT . 'inc/plugins/dvz_stream/StreamEvent.php';

// hooks
if (!defined('IN_ADMINCP')) {
    require MYBB_ROOT . 'inc/plugins/dvz_stream/hooks_frontend.php';

    $plugins->add_hook('global_start', 'dvzStream\global_start');
    $plugins->add_hook('misc_start', 'dvzStream\misc_start');
    $plugins->add_hook('index_end', 'dvzStream\index_end');
    $plugins->add_hook('xmlhttp', 'dvzStream\xmlhttp');
} else {
    require MYBB_ROOT . 'inc/plugins/dvz_stream/hooks_acp.php';

    $plugins->add_hook('admin_config_settings_start', 'dvzStream\admin_config_settings_start');
    $plugins->add_hook('admin_config_settings_change', 'dvzStream\admin_config_settings_start');
}

// init
define('dvzStream\DEVELOPMENT_MODE', 0);

$dvzStreamStreams = [];

function dvz_stream_info()
{
    global $lang;

    $lang->load('dvz_stream');

    return [
        'name'          => 'DVZ Stream',
        'description'   => $lang->dvz_stream_description,
        'website'       => 'https://devilshakerz.com/',
        'author'        => 'Tomasz \'Devilshakerz\' Mlynski',
        'authorsite'    => 'https://devilshakerz.com/',
        'version'       => '2.2',
        'codename'      => 'dvz_stream',
        'compatibility' => '18*',
    ];
}

// MyBB plugin system
function dvz_stream_install()
{
    global $db;

    switch ($db->type) {
        case 'pgsql':
        case 'sqlite':
            // `KEY tid (tid, uid)` not created by MyBB on PostgreSQL/SQLite
            $db->write_query("
                CREATE INDEX IF NOT EXISTS mybb_posts_tid
                    ON " . TABLE_PREFIX . "posts (tid ASC)
            ");

            $db->write_query("
                CREATE INDEX IF NOT EXISTS mybb_threads_visible_tid
                    ON " . TABLE_PREFIX . "threads (tid DESC)
                    WHERE visible = 1
            ");

            break;
        default:
            if (!$db->index_exists('threads', 'mybb_threads_visible_tid')) {
                $db->write_query("
                    CREATE INDEX mybb_threads_visible_tid
                        ON " . TABLE_PREFIX . "threads (visible DESC, tid DESC)
                ");
            }

            break;
    }
}

function dvz_stream_uninstall()
{
    global $db, $PL;

    dvz_stream_admin_load_pluginlibrary();

    // database
    $indexes = [
        'posts' => ['mybb_posts_tid'],
        'threads' => ['mybb_threads_visible_tid'],
    ];

    foreach ($indexes as $tableName => $tableIndexNames) {
        foreach ($tableIndexNames as $tableIndexName) {
            if ($db->index_exists($tableName, $tableIndexName)) {
                $db->drop_index($tableName, $tableIndexName);
            }
        }
    }

    // settings
    $settingGroupId = $db->fetch_field(
        $db->simple_select('settinggroups', 'gid', "name='dvz_stream'"),
        'gid'
    );

    $PL->settings_delete('dvz_stream', true);

    // templates
    $PL->templates_delete('dvzstream', true);

    // stylesheets
    $PL->stylesheet_delete('dvz_stream', true);
}

function dvz_stream_is_installed()
{
    global $db;

    // manual check to avoid caching issues
    $query = $db->simple_select('settinggroups', 'gid', "name='dvz_stream'");

    return (bool)$db->num_rows($query);
}

function dvz_stream_activate()
{
    global $PL;

    dvz_stream_admin_load_pluginlibrary();

    // templates
    $templates = [];

    $directory = new DirectoryIterator(MYBB_ROOT . 'inc/plugins/dvz_stream/templates');

    foreach ($directory as $file) {
        if (!$file->isDot() && !$file->isDir()) {
            $templateName = $file->getPathname();
            $templateName = basename($templateName, '.tpl');
            $templates[$templateName] = file_get_contents($file->getPathname());
        }
    }

    $PL->templates('dvzstream', 'DVZ Stream', $templates);

    // stylesheets
    $stylesheets = [
        'dvz_stream' => [
            'attached_to' => 'index.php|misc.php?stream',
        ],
    ];

    foreach ($stylesheets as $stylesheetName => $stylesheet) {
        $PL->stylesheet(
            $stylesheetName,
            file_get_contents(MYBB_ROOT . 'inc/plugins/dvz_stream/stylesheets/' . $stylesheetName . '.css'),
            $stylesheet['attached_to']
        );
    }

    // settings
    $PL->settings(
        'dvz_stream',
        'DVZ Stream',
        'Settings for DVZ Stream.',
        [
            'active_streams' => [
                'title'       => 'Active streams',
                'description' => 'Comma-separated names of streams to be displayed.',
                'optionscode' => 'text',
                'value'       => 'posts,threads,users',
            ],
            'group_events_by' => [
                'title'       => 'Event grouping',
                'description' => 'Comma-separated names of event groups for which only the most recent entry should be displayed.',
                'optionscode' => 'text',
                'value'       => 'thread',
            ],
            'widget_enabled' => [
                'title'       => 'Index page widget',
                'description' => 'Enable a <code>{$dvz_stream}</code> widget that can be inserted to forum index templates.',
                'optionscode' => 'onoff',
                'value'       => '1',
            ],
            'limit_widget' => [
                'title'       => 'Number of entries in the Stream widget',
                'description' => '',
                'optionscode' => 'numeric',
                'value'       => '6',
            ],
            'interval_widget' => [
                'title'       => 'Refresh interval: Stream widget (seconds)',
                'description' => 'Interval between AJAX Stream update requests (lower values provide better synchronization but cause higher server load). Set 0 to disable the auto-refreshing feature.',
                'optionscode' => 'numeric',
                'value'       => '10',
            ],
            'limit_page' => [
                'title'       => 'Number of entries on the Stream page',
                'description' => '',
                'optionscode' => 'numeric',
                'value'       => '20',
            ],
            'interval_page' => [
                'title'       => 'Refresh interval: Stream page (seconds)',
                'description' => '',
                'optionscode' => 'numeric',
                'value'       => '5',
            ],
            'lazyload' => [
                'title'       => 'Lazy load',
                'description' => 'Start loading data only when the Stream is actually being displayed on the screen (the page is scrolled to the Stream position).',
                'optionscode' => 'select
off=Disabled
start=Check if on display to start
always=Always check if on display to refresh',
                'value'       => 'always',
            ],
            'groups_view' => [
                'title'       => 'Group permissions: View',
                'description' => '',
                'optionscode' => 'groupselect',
                'value'       => '-1',
            ],
            'groups_update' => [
                'title'       => 'Group permissions: Auto-update',
                'description' => '',
                'optionscode' => 'groupselect',
                'value'       => '-1',
            ],
            'hidden_forums' => [
                'title'       => 'Hidden forums',
                'description' => 'Select which forums should be omitted by streams.',
                'optionscode' => 'forumselect',
                'value'       => '',
            ],
        ]
    );
}

// helpers
function dvz_stream_admin_load_pluginlibrary()
{
    global $PL, $lang;

    if (!defined('PLUGINLIBRARY')) {
        define('PLUGINLIBRARY', MYBB_ROOT . 'inc/plugins/pluginlibrary.php');
    }

    if (!file_exists(PLUGINLIBRARY)) {
        $lang->load('dvz_stream');

        flash_message($lang->dvz_stream_admin_pluginlibrary_missing, 'error');

        admin_redirect('index.php?module=config-plugins');
    } elseif (!isset($PL)) {
        require_once PLUGINLIBRARY;
    }
}
